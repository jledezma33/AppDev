﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TimeSheet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeSheet.Tests
{
    [TestClass(), Ignore]
    public class EmployeeTests
    {
        [TestMethod()]
        public void EmployeeTest()
        {
            throw new NotImplementedException();
        }
    }
}